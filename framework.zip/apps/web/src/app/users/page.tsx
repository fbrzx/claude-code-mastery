'use client'

import { useState, useEffect, useCallback } from 'react'
import {
  Button,
  Card,
  CardBody,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  TableHeaderCell,
  Avatar,
  Alert,
} from '@repo/ui'
import { UserModal } from '@/components/user-modal'
import { DeleteConfirmModal } from '@/components/delete-confirm-modal'
import {
  User,
  CreateUserData,
  UpdateUserData,
  getUsers,
  createUser,
  updateUser,
  deleteUser,
  getImageUrl,
} from '@/lib/api'

interface AlertState {
  type: 'success' | 'error'
  message: string
}

export default function UsersPage() {
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [alert, setAlert] = useState<AlertState | null>(null)

  // Modal states
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  const [editingUser, setEditingUser] = useState<User | null>(null)
  const [deletingUser, setDeletingUser] = useState<User | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const fetchUsers = useCallback(async () => {
    try {
      const data = await getUsers()
      setUsers(data)
    } catch (err) {
      setAlert({
        type: 'error',
        message: err instanceof Error ? err.message : 'Failed to fetch users',
      })
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchUsers()
  }, [fetchUsers])

  const handleCreate = async (data: CreateUserData | UpdateUserData) => {
    setIsSubmitting(true)
    try {
      await createUser(data as CreateUserData)
      setAlert({ type: 'success', message: 'User created successfully! Check Mailpit for email notification.' })
      await fetchUsers()
    } catch (err) {
      setAlert({
        type: 'error',
        message: err instanceof Error ? err.message : 'Failed to create user',
      })
      throw err
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleUpdate = async (data: CreateUserData | UpdateUserData) => {
    if (!editingUser) return
    setIsSubmitting(true)
    try {
      await updateUser(editingUser.id, data as UpdateUserData)
      setAlert({ type: 'success', message: 'User updated successfully! Check Mailpit for email notification.' })
      await fetchUsers()
    } catch (err) {
      setAlert({
        type: 'error',
        message: err instanceof Error ? err.message : 'Failed to update user',
      })
      throw err
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDelete = async () => {
    if (!deletingUser) return
    setIsSubmitting(true)
    try {
      await deleteUser(deletingUser.id)
      setAlert({ type: 'success', message: 'User deleted successfully! Check Mailpit for email notification.' })
      await fetchUsers()
    } catch (err) {
      setAlert({
        type: 'error',
        message: err instanceof Error ? err.message : 'Failed to delete user',
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    })
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Users</h1>
        <Button variant="primary" onClick={() => setIsCreateModalOpen(true)}>
          + New User
        </Button>
      </div>

      {alert && (
        <div className="mb-4">
          <Alert variant={alert.type} onClose={() => setAlert(null)}>
            {alert.message}
          </Alert>
        </div>
      )}

      <Card>
        <CardBody>
          {loading ? (
            <div className="flex justify-center py-8">
              <span className="loading loading-spinner loading-lg"></span>
            </div>
          ) : users.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-base-content/60">No users found. Create your first user!</p>
            </div>
          ) : (
            <Table zebra>
              <TableHead>
                <TableRow>
                  <TableHeaderCell>User</TableHeaderCell>
                  <TableHeaderCell>Email</TableHeaderCell>
                  <TableHeaderCell>Created</TableHeaderCell>
                  <TableHeaderCell>Actions</TableHeaderCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {users.map((user) => (
                  <TableRow key={user.id} hover>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar
                          src={getImageUrl(user.image)}
                          alt={user.name || user.email}
                          size="sm"
                          placeholder={user.name || user.email}
                        />
                        <span className="font-medium">{user.name || '(No name)'}</span>
                      </div>
                    </TableCell>
                    <TableCell>{user.email}</TableCell>
                    <TableCell>{formatDate(user.createdAt)}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setEditingUser(user)}
                        >
                          Edit
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setDeletingUser(user)}
                        >
                          Delete
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardBody>
      </Card>

      {/* Create User Modal */}
      <UserModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onSubmit={handleCreate}
        isLoading={isSubmitting}
      />

      {/* Edit User Modal */}
      <UserModal
        isOpen={!!editingUser}
        onClose={() => setEditingUser(null)}
        user={editingUser}
        onSubmit={handleUpdate}
        isLoading={isSubmitting}
      />

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={!!deletingUser}
        onClose={() => setDeletingUser(null)}
        onConfirm={handleDelete}
        title="Delete User"
        message={`Are you sure you want to delete ${deletingUser?.name || deletingUser?.email}? This action cannot be undone.`}
        isLoading={isSubmitting}
      />
    </div>
  )
}

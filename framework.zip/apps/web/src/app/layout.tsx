import type { Metadata } from 'next'
import { Navbar } from '@/components/navbar'
import './globals.css'

export const metadata: Metadata = {
  title: 'Precision Audit Platform',
  description: 'Precision Audit Platform - Modern audit management solution',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" data-theme="light" suppressHydrationWarning>
      <body className="min-h-screen bg-base-200">
        <Navbar />
        <main>{children}</main>
      </body>
    </html>
  )
}

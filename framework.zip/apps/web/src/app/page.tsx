import { Button, Card, CardBody, CardTitle, CardActions } from '@repo/ui'

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-8">
      {/* Hero Section */}
      <div className="hero min-h-[60vh]">
        <div className="hero-content text-center">
          <div className="max-w-2xl">
            <h1 className="text-5xl font-bold">Precision Audit Platform</h1>
            <p className="py-6 text-lg">
              A modern audit management solution built with Next.js, daisyUI, and a
              powerful monorepo architecture. Manage audits, track compliance, and
              generate reports with ease.
            </p>
            <div className="flex gap-4 justify-center">
              <a href="/users">
                <Button variant="primary" size="lg">
                  Manage Users
                </Button>
              </a>
              <Button variant="ghost" size="lg">
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-12">
        <h2 className="text-3xl font-bold text-center mb-8">Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card bordered>
            <CardBody>
              <CardTitle>Audit Management</CardTitle>
              <p>
                Create, track, and manage audits with a streamlined workflow.
                Keep all your audit data organized in one place.
              </p>
              <CardActions>
                <Button variant="primary" size="sm">
                  Explore
                </Button>
              </CardActions>
            </CardBody>
          </Card>

          <Card bordered>
            <CardBody>
              <CardTitle>Compliance Tracking</CardTitle>
              <p>
                Monitor compliance requirements and ensure your organization
                meets all regulatory standards with real-time tracking.
              </p>
              <CardActions>
                <Button variant="secondary" size="sm">
                  Explore
                </Button>
              </CardActions>
            </CardBody>
          </Card>

          <Card bordered>
            <CardBody>
              <CardTitle>Report Generation</CardTitle>
              <p>
                Generate comprehensive audit reports with customizable templates.
                Export to PDF, Excel, or share directly with stakeholders.
              </p>
              <CardActions>
                <Button variant="accent" size="sm">
                  Explore
                </Button>
              </CardActions>
            </CardBody>
          </Card>
        </div>
      </div>

      {/* Stats Section */}
      <div className="py-12">
        <div className="stats shadow w-full">
          <div className="stat">
            <div className="stat-title">Active Audits</div>
            <div className="stat-value text-primary">31</div>
            <div className="stat-desc">Jan 1st - Feb 1st</div>
          </div>

          <div className="stat">
            <div className="stat-title">Compliance Rate</div>
            <div className="stat-value text-secondary">94.6%</div>
            <div className="stat-desc">+21% from last month</div>
          </div>

          <div className="stat">
            <div className="stat-title">Reports Generated</div>
            <div className="stat-value">1,200</div>
            <div className="stat-desc">+90 this week</div>
          </div>
        </div>
      </div>
    </div>
  )
}

const API_BASE_URL = 'http://localhost:3001'

export interface User {
  id: string
  email: string
  name: string | null
  image: string | null
  createdAt: string
  updatedAt: string
}

export interface CreateUserData {
  email: string
  name?: string
  image?: string
}

export interface UpdateUserData {
  email?: string
  name?: string
  image?: string
}

export interface UploadResponse {
  key: string
}

export interface ApiError {
  error: string
  message: string
}

async function handleResponse<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const error: ApiError = await response.json().catch(() => ({
      error: 'Error',
      message: `HTTP error ${response.status}`,
    }))
    throw new Error(error.message)
  }
  return response.json()
}

export async function getUsers(): Promise<User[]> {
  const response = await fetch(`${API_BASE_URL}/users`)
  return handleResponse<User[]>(response)
}

export async function getUser(id: string): Promise<User> {
  const response = await fetch(`${API_BASE_URL}/users/${id}`)
  return handleResponse<User>(response)
}

export async function createUser(data: CreateUserData): Promise<User> {
  const response = await fetch(`${API_BASE_URL}/users`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  })
  return handleResponse<User>(response)
}

export async function updateUser(id: string, data: UpdateUserData): Promise<User> {
  const response = await fetch(`${API_BASE_URL}/users/${id}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  })
  return handleResponse<User>(response)
}

export async function deleteUser(id: string): Promise<void> {
  const response = await fetch(`${API_BASE_URL}/users/${id}`, {
    method: 'DELETE',
  })
  if (!response.ok) {
    const error: ApiError = await response.json().catch(() => ({
      error: 'Error',
      message: `HTTP error ${response.status}`,
    }))
    throw new Error(error.message)
  }
}

export async function uploadFile(file: File): Promise<UploadResponse> {
  const formData = new FormData()
  formData.append('file', file)

  const response = await fetch(`${API_BASE_URL}/upload`, {
    method: 'POST',
    body: formData,
  })
  return handleResponse<UploadResponse>(response)
}

const MINIO_URL = 'http://localhost:9000'
const MINIO_BUCKET = 'uploads'

export function getImageUrl(key: string | null | undefined): string | undefined {
  if (!key) return undefined
  return `${MINIO_URL}/${MINIO_BUCKET}/${key}`
}

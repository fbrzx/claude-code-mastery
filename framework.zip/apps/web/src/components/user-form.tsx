'use client'

import { useState, useRef } from 'react'
import { Button, Input, Avatar } from '@repo/ui'
import { User, CreateUserData, UpdateUserData, uploadFile, getImageUrl } from '@/lib/api'

interface UserFormProps {
  user?: User | null
  onSubmit: (data: CreateUserData | UpdateUserData) => Promise<void>
  onCancel: () => void
  isLoading?: boolean
}

export function UserForm({ user, onSubmit, onCancel, isLoading }: UserFormProps) {
  const [name, setName] = useState(user?.name || '')
  const [email, setEmail] = useState(user?.email || '')
  const [imageKey, setImageKey] = useState(user?.image || '')
  const [previewUrl, setPreviewUrl] = useState<string | undefined>(
    user?.image ? getImageUrl(user.image) : undefined
  )
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Preview
    const reader = new FileReader()
    reader.onloadend = () => {
      setPreviewUrl(reader.result as string)
    }
    reader.readAsDataURL(file)

    // Upload
    setUploading(true)
    setError(null)
    try {
      const result = await uploadFile(file)
      setImageKey(result.key)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to upload image')
      setPreviewUrl(user?.image ? getImageUrl(user.image) : undefined)
    } finally {
      setUploading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)

    if (!email.trim()) {
      setError('Email is required')
      return
    }

    try {
      await onSubmit({
        email: email.trim(),
        name: name.trim() || undefined,
        image: imageKey || undefined,
      })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred')
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <div className="alert alert-error">
          <span>{error}</span>
        </div>
      )}

      <div className="flex flex-col items-center gap-4">
        <Avatar
          src={previewUrl}
          alt={name || email}
          size="lg"
          placeholder={name || email}
        />
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          className="hidden"
        />
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
          loading={uploading}
        >
          {uploading ? 'Uploading...' : 'Change Photo'}
        </Button>
      </div>

      <Input
        label="Name"
        type="text"
        placeholder="John Doe"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />

      <Input
        label="Email"
        type="email"
        placeholder="john@example.com"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        required
      />

      <div className="modal-action">
        <Button type="button" variant="ghost" onClick={onCancel} disabled={isLoading}>
          Cancel
        </Button>
        <Button type="submit" variant="primary" disabled={isLoading || uploading} loading={isLoading}>
          {user ? 'Update' : 'Create'}
        </Button>
      </div>
    </form>
  )
}

'use client'

import { Modal } from '@repo/ui'
import { UserForm } from './user-form'
import { User, CreateUserData, UpdateUserData } from '@/lib/api'

interface UserModalProps {
  isOpen: boolean
  onClose: () => void
  user?: User | null
  onSubmit: (data: CreateUserData | UpdateUserData) => Promise<void>
  isLoading?: boolean
}

export function UserModal({ isOpen, onClose, user, onSubmit, isLoading }: UserModalProps) {
  const handleSubmit = async (data: CreateUserData | UpdateUserData) => {
    await onSubmit(data)
    onClose()
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={user ? 'Edit User' : 'Create User'}>
      <UserForm
        user={user}
        onSubmit={handleSubmit}
        onCancel={onClose}
        isLoading={isLoading}
      />
    </Modal>
  )
}

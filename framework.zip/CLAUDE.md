# Precision Audit Platform

## Overview

A precision audit platform built as a TypeScript monorepo.

## Tech Stack

- **Runtime**: Node.js 20+
- **Package Manager**: pnpm (REQUIRED)
- **Web Framework**: Next.js 14 (App Router)
- **API Framework**: Fastify
- **ORM**: Prisma
- **Database**: PostgreSQL (via docker-compose)
- **Cache**: Redis (via docker-compose)
- **Mail**: Mailpit (via docker-compose)
- **Storage**: MinIO (via docker-compose)
- **UI Library**: daisyUI + Tailwind CSS
- **Testing**: Vitest

## Monorepo Structure

```
precision-audit-platform/
├── apps/
│   └── web/           # Next.js web application
├── services/
│   └── api/           # Fastify API service
├── packages/
│   ├── config/        # Shared TypeScript configs
│   ├── db/            # Prisma schema and client
│   └── ui/            # Shared UI components (daisyUI)
├── .claude/
│   ├── commands/      # Project-specific commands
│   └── docs/          # Claude-generated documentation
└── docker-compose.yml # Local infrastructure
```

## Commands

| Command | Description |
|---------|-------------|
| `make install` | Install all dependencies |
| `make dev` | Start development (all workspaces) |
| `make build` | Build all packages |
| `make test` | Run tests |
| `make lint` | Check code style |
| `make typecheck` | Run TypeScript type checking |
| `make up` | Start local infrastructure (Docker) |
| `make down` | Stop local infrastructure |
| `make db-migrate` | Run Prisma migrations |
| `make db-generate` | Generate Prisma client |
| `make db-studio` | Open Prisma Studio |
| `make reset` | Reset everything (clean install) |

## Environment Variables

See `.env.example` for required environment variables:

- `DATABASE_URL` - PostgreSQL connection string
- `REDIS_URL` - Redis connection string
- `SMTP_HOST`, `SMTP_PORT`, `SMTP_FROM` - Mail configuration
- `S3_ENDPOINT`, `S3_ACCESS_KEY`, `S3_SECRET_KEY`, `S3_BUCKET` - Object storage

## Local Services

| Service | URL | Description |
|---------|-----|-------------|
| Web App | http://localhost:3000 | Next.js application |
| API | http://localhost:3001 | Fastify API |
| Mailpit | http://localhost:8025 | Email testing UI |
| MinIO Console | http://localhost:9001 | Object storage UI |
| Prisma Studio | http://localhost:5555 | Database UI |

## Development Workflow

1. Start infrastructure: `make up`
2. Install dependencies: `make install`
3. Copy environment: `cp .env.example .env`
4. Run migrations: `make db-migrate`
5. Start development: `make dev`

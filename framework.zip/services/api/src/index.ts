import { config } from 'dotenv'
import { resolve } from 'path'

// Load environment variables from monorepo root
config({ path: resolve(import.meta.dirname, '../../../.env') })

import Fastify, { FastifyRequest, FastifyReply } from 'fastify'
import cors from '@fastify/cors'
import multipart from '@fastify/multipart'
import { prisma, Prisma } from '@repo/db'
import { uploadFile, deleteFile } from './lib/minio.js'
import { sendEmail } from './lib/email.js'
import { randomUUID } from 'crypto'

// Notification email recipient for all user operations
const NOTIFICATION_EMAIL = 'test@example.com'

// Type definitions for request bodies and params
interface CreateUserBody {
  email: string
  name?: string
  image?: string
}

interface UpdateUserBody {
  email?: string
  name?: string
  image?: string
}

interface UserParams {
  id: string
}

interface UserResponse {
  id: string
  email: string
  name: string | null
  image: string | null
  createdAt: Date
  updatedAt: Date
}

interface HealthResponse {
  status: 'ok' | 'error'
  timestamp: string
}

interface ErrorResponse {
  error: string
  message: string
}

interface UploadResponse {
  key: string
}

const fastify = Fastify({
  logger: true,
})

// Register CORS
await fastify.register(cors, {
  origin: true,
})

// Register multipart for file uploads
await fastify.register(multipart, {
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB max file size
  },
})

// Global error handler
fastify.setErrorHandler(
  async (error: Error, request: FastifyRequest, reply: FastifyReply) => {
    request.log.error(error)

    // Handle Prisma errors
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      if (error.code === 'P2002') {
        return reply.status(409).send({
          error: 'Conflict',
          message: 'A user with this email already exists',
        } satisfies ErrorResponse)
      }
      if (error.code === 'P2025') {
        return reply.status(404).send({
          error: 'Not Found',
          message: 'User not found',
        } satisfies ErrorResponse)
      }
    }

    // Handle validation errors
    if (error.name === 'ValidationError') {
      return reply.status(400).send({
        error: 'Bad Request',
        message: error.message,
      } satisfies ErrorResponse)
    }

    // Default error response
    return reply.status(500).send({
      error: 'Internal Server Error',
      message:
        process.env.NODE_ENV === 'development'
          ? error.message
          : 'An unexpected error occurred',
    } satisfies ErrorResponse)
  }
)

// Health check endpoint
fastify.get<{ Reply: HealthResponse }>('/health', async () => {
  return {
    status: 'ok',
    timestamp: new Date().toISOString(),
  }
})

// Upload file endpoint
fastify.post<{ Reply: UploadResponse | ErrorResponse }>(
  '/upload',
  async (request, reply) => {
    const file = await request.file()

    if (!file) {
      return reply.status(400).send({
        error: 'Bad Request',
        message: 'No file provided',
      })
    }

    const buffer = await file.toBuffer()
    const extension = file.filename.split('.').pop() || 'bin'
    const key = `${randomUUID()}.${extension}`

    await uploadFile(key, buffer, file.mimetype)

    return reply.status(201).send({ key })
  }
)

// List all users
fastify.get<{ Reply: UserResponse[] }>('/users', async () => {
  const users = await prisma.user.findMany({
    orderBy: { createdAt: 'desc' },
  })
  return users
})

// Get user by ID
fastify.get<{ Params: UserParams; Reply: UserResponse | ErrorResponse }>(
  '/users/:id',
  async (request, reply) => {
    const { id } = request.params

    const user = await prisma.user.findUnique({
      where: { id },
    })

    if (!user) {
      return reply.status(404).send({
        error: 'Not Found',
        message: 'User not found',
      })
    }

    return user
  }
)

// Create a new user
fastify.post<{ Body: CreateUserBody; Reply: UserResponse | ErrorResponse }>(
  '/users',
  async (request, reply) => {
    const { email, name, image } = request.body

    // Basic validation
    if (!email || typeof email !== 'string') {
      return reply.status(400).send({
        error: 'Bad Request',
        message: 'Email is required and must be a string',
      })
    }

    // Simple email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return reply.status(400).send({
        error: 'Bad Request',
        message: 'Invalid email format',
      })
    }

    const user = await prisma.user.create({
      data: {
        email,
        name: name || null,
        image: image || null,
      },
    })

    // Send email notification
    try {
      await sendEmail(
        NOTIFICATION_EMAIL,
        'New User Created',
        `
          <h1>New User Created</h1>
          <p><strong>ID:</strong> ${user.id}</p>
          <p><strong>Email:</strong> ${user.email}</p>
          <p><strong>Name:</strong> ${user.name || 'N/A'}</p>
          <p><strong>Image:</strong> ${user.image || 'N/A'}</p>
          <p><strong>Created At:</strong> ${user.createdAt.toISOString()}</p>
        `
      )
    } catch (err) {
      request.log.error(err, 'Failed to send email notification')
    }

    return reply.status(201).send(user)
  }
)

// Update a user
fastify.put<{
  Params: UserParams
  Body: UpdateUserBody
  Reply: UserResponse | ErrorResponse
}>('/users/:id', async (request, reply) => {
  const { id } = request.params
  const { email, name, image } = request.body

  // Validate email format if provided
  if (email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return reply.status(400).send({
        error: 'Bad Request',
        message: 'Invalid email format',
      })
    }
  }

  const user = await prisma.user.update({
    where: { id },
    data: {
      ...(email !== undefined && { email }),
      ...(name !== undefined && { name }),
      ...(image !== undefined && { image }),
    },
  })

  // Send email notification
  try {
    await sendEmail(
      NOTIFICATION_EMAIL,
      'User Updated',
      `
        <h1>User Updated</h1>
        <p><strong>ID:</strong> ${user.id}</p>
        <p><strong>Email:</strong> ${user.email}</p>
        <p><strong>Name:</strong> ${user.name || 'N/A'}</p>
        <p><strong>Image:</strong> ${user.image || 'N/A'}</p>
        <p><strong>Updated At:</strong> ${user.updatedAt.toISOString()}</p>
      `
    )
  } catch (err) {
    request.log.error(err, 'Failed to send email notification')
  }

  return user
})

// Delete a user
fastify.delete<{ Params: UserParams; Reply: { success: boolean } | ErrorResponse }>(
  '/users/:id',
  async (request, reply) => {
    const { id } = request.params

    // Get user first to include in notification
    const user = await prisma.user.findUnique({
      where: { id },
    })

    if (!user) {
      return reply.status(404).send({
        error: 'Not Found',
        message: 'User not found',
      })
    }

    // Delete associated image from MinIO if exists
    if (user.image) {
      try {
        await deleteFile(user.image)
      } catch (err) {
        request.log.error(err, 'Failed to delete user image from MinIO')
      }
    }

    await prisma.user.delete({
      where: { id },
    })

    // Send email notification
    try {
      await sendEmail(
        NOTIFICATION_EMAIL,
        'User Deleted',
        `
          <h1>User Deleted</h1>
          <p><strong>ID:</strong> ${user.id}</p>
          <p><strong>Email:</strong> ${user.email}</p>
          <p><strong>Name:</strong> ${user.name || 'N/A'}</p>
          <p><strong>Deleted At:</strong> ${new Date().toISOString()}</p>
        `
      )
    } catch (err) {
      request.log.error(err, 'Failed to send email notification')
    }

    return { success: true }
  }
)

// Graceful shutdown handler
const shutdown = async (signal: string) => {
  fastify.log.info(`Received ${signal}, shutting down gracefully...`)
  try {
    await fastify.close()
    await prisma.$disconnect()
    fastify.log.info('Server closed successfully')
    process.exit(0)
  } catch (err) {
    fastify.log.error(err, 'Error during shutdown')
    process.exit(1)
  }
}

process.on('SIGTERM', () => shutdown('SIGTERM'))
process.on('SIGINT', () => shutdown('SIGINT'))

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  fastify.log.error(error, 'Uncaught exception')
  shutdown('uncaughtException')
})

process.on('unhandledRejection', (reason) => {
  fastify.log.error(reason, 'Unhandled rejection')
  shutdown('unhandledRejection')
})

// Start server
const start = async () => {
  try {
    const port = parseInt(process.env.PORT || '3001', 10)
    await fastify.listen({ port, host: '0.0.0.0' })
    fastify.log.info(`Server listening on port ${port}`)
  } catch (err) {
    fastify.log.error(err)
    process.exit(1)
  }
}

start()

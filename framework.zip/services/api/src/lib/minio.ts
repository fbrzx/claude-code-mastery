import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  DeleteObjectCommand,
} from '@aws-sdk/client-s3'
import { getSignedUrl } from '@aws-sdk/s3-request-presigner'

// MinIO client configured for S3-compatible API
const s3Client = new S3Client({
  endpoint: process.env.S3_ENDPOINT || 'http://localhost:9000',
  region: 'us-east-1', // MinIO doesn't use regions, but SDK requires one
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY || 'minioadmin',
    secretAccessKey: process.env.S3_SECRET_KEY || 'minioadmin',
  },
  forcePathStyle: true, // Required for MinIO
})

const bucket = process.env.S3_BUCKET || 'uploads'

/**
 * Upload a file to MinIO
 * @param key - The object key (file path in bucket)
 * @param body - The file content as Buffer
 * @param contentType - The MIME type of the file
 * @returns The object key
 */
export async function uploadFile(
  key: string,
  body: Buffer,
  contentType: string
): Promise<string> {
  const command = new PutObjectCommand({
    Bucket: bucket,
    Key: key,
    Body: body,
    ContentType: contentType,
  })

  await s3Client.send(command)
  return key
}

/**
 * Get a presigned URL for accessing a file
 * @param key - The object key
 * @param expiresIn - URL expiration time in seconds (default: 1 hour)
 * @returns The presigned URL
 */
export async function getFileUrl(
  key: string,
  expiresIn: number = 3600
): Promise<string> {
  const command = new GetObjectCommand({
    Bucket: bucket,
    Key: key,
  })

  const url = await getSignedUrl(s3Client, command, { expiresIn })
  return url
}

/**
 * Delete a file from MinIO
 * @param key - The object key to delete
 */
export async function deleteFile(key: string): Promise<void> {
  const command = new DeleteObjectCommand({
    Bucket: bucket,
    Key: key,
  })

  await s3Client.send(command)
}

import nodemailer from 'nodemailer'

// Create reusable transporter using SMTP
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'localhost',
  port: parseInt(process.env.SMTP_PORT || '1025', 10),
  secure: false, // Mailpit doesn't use TLS
  auth: undefined, // No auth for Mailpit
})

const defaultFrom = process.env.SMTP_FROM || 'noreply@localhost'

/**
 * Send an email
 * @param to - Recipient email address
 * @param subject - Email subject
 * @param html - HTML content of the email
 */
export async function sendEmail(
  to: string,
  subject: string,
  html: string
): Promise<void> {
  await transporter.sendMail({
    from: defaultFrom,
    to,
    subject,
    html,
  })
}

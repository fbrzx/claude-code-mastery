# Precision Audit Platform

A precision audit platform built with Next.js, Fastify, and Prisma.

## Quick Start

```bash
# Start local infrastructure
make up

# Install dependencies
make install

# Copy environment variables
cp .env.example .env

# Run database migrations
make db-migrate

# Start development
make dev
```

## Services

- **Web App**: http://localhost:3000
- **API**: http://localhost:3001
- **Mailpit**: http://localhost:8025
- **MinIO Console**: http://localhost:9001

## Tech Stack

- **Frontend**: Next.js 14, React 18, daisyUI, Tailwind CSS
- **Backend**: Fastify, Prisma
- **Database**: PostgreSQL
- **Cache**: Redis
- **Infrastructure**: Docker Compose

## Project Structure

```
├── apps/web/          # Next.js web application
├── services/api/      # Fastify API service
├── packages/
│   ├── config/        # Shared TypeScript configs
│   ├── db/            # Prisma schema and client
│   └── ui/            # Shared UI components
└── docker-compose.yml # Local infrastructure
```

## Commands

```bash
make install      # Install dependencies
make dev          # Start development
make build        # Build all packages
make test         # Run tests
make lint         # Lint code
make up           # Start Docker services
make down         # Stop Docker services
make db-migrate   # Run migrations
make db-studio    # Open Prisma Studio
make reset        # Clean reset
```

## License

Private

import { HTMLAttributes, TableHTMLAttributes, TdHTMLAttributes, ThHTMLAttributes, forwardRef } from 'react'

export interface TableProps extends TableHTMLAttributes<HTMLTableElement> {
  zebra?: boolean
  pinRows?: boolean
  pinCols?: boolean
}

export const Table = forwardRef<HTMLTableElement, TableProps>(
  ({ className = '', zebra = false, pinRows = false, pinCols = false, children, ...props }, ref) => {
    const zebraClass = zebra ? 'table-zebra' : ''
    const pinRowsClass = pinRows ? 'table-pin-rows' : ''
    const pinColsClass = pinCols ? 'table-pin-cols' : ''

    return (
      <div className="overflow-x-auto">
        <table
          ref={ref}
          className={`table ${zebraClass} ${pinRowsClass} ${pinColsClass} ${className}`.trim()}
          {...props}
        >
          {children}
        </table>
      </div>
    )
  }
)

Table.displayName = 'Table'

export interface TableHeadProps extends HTMLAttributes<HTMLTableSectionElement> {}

export const TableHead = forwardRef<HTMLTableSectionElement, TableHeadProps>(
  ({ className = '', children, ...props }, ref) => {
    return (
      <thead ref={ref} className={className} {...props}>
        {children}
      </thead>
    )
  }
)

TableHead.displayName = 'TableHead'

export interface TableBodyProps extends HTMLAttributes<HTMLTableSectionElement> {}

export const TableBody = forwardRef<HTMLTableSectionElement, TableBodyProps>(
  ({ className = '', children, ...props }, ref) => {
    return (
      <tbody ref={ref} className={className} {...props}>
        {children}
      </tbody>
    )
  }
)

TableBody.displayName = 'TableBody'

export interface TableRowProps extends HTMLAttributes<HTMLTableRowElement> {
  hover?: boolean
  active?: boolean
}

export const TableRow = forwardRef<HTMLTableRowElement, TableRowProps>(
  ({ className = '', hover = false, active = false, children, ...props }, ref) => {
    const hoverClass = hover ? 'hover' : ''
    const activeClass = active ? 'active' : ''

    return (
      <tr ref={ref} className={`${hoverClass} ${activeClass} ${className}`.trim()} {...props}>
        {children}
      </tr>
    )
  }
)

TableRow.displayName = 'TableRow'

export interface TableCellProps extends TdHTMLAttributes<HTMLTableCellElement> {}

export const TableCell = forwardRef<HTMLTableCellElement, TableCellProps>(
  ({ className = '', children, ...props }, ref) => {
    return (
      <td ref={ref} className={className} {...props}>
        {children}
      </td>
    )
  }
)

TableCell.displayName = 'TableCell'

export interface TableHeaderCellProps extends ThHTMLAttributes<HTMLTableCellElement> {}

export const TableHeaderCell = forwardRef<HTMLTableCellElement, TableHeaderCellProps>(
  ({ className = '', children, ...props }, ref) => {
    return (
      <th ref={ref} className={className} {...props}>
        {children}
      </th>
    )
  }
)

TableHeaderCell.displayName = 'TableHeaderCell'

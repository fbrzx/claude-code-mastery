import { HTMLAttributes, forwardRef } from 'react'

export interface AvatarProps extends HTMLAttributes<HTMLDivElement> {
  src?: string
  alt?: string
  size?: 'sm' | 'md' | 'lg'
  placeholder?: string
}

const sizeClasses = {
  sm: 'w-8',
  md: 'w-12',
  lg: 'w-16',
}

const placeholderSizeClasses = {
  sm: 'text-xs',
  md: 'text-base',
  lg: 'text-xl',
}

function getInitials(text: string): string {
  return text
    .split(' ')
    .map((word) => word[0])
    .join('')
    .toUpperCase()
    .slice(0, 2)
}

export const Avatar = forwardRef<HTMLDivElement, AvatarProps>(
  ({ className = '', src, alt = '', size = 'md', placeholder, ...props }, ref) => {
    const sizeClass = sizeClasses[size]
    const placeholderSizeClass = placeholderSizeClasses[size]

    const initials = placeholder ? getInitials(placeholder) : alt ? getInitials(alt) : '?'

    return (
      <div ref={ref} className={`avatar ${!src ? 'placeholder' : ''} ${className}`.trim()} {...props}>
        <div className={`${sizeClass} rounded-full ${!src ? 'bg-neutral text-neutral-content' : ''}`}>
          {src ? (
            <img src={src} alt={alt} />
          ) : (
            <span className={placeholderSizeClass}>{initials}</span>
          )}
        </div>
      </div>
    )
  }
)

Avatar.displayName = 'Avatar'

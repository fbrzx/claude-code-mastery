'use client'

import { HTMLAttributes, forwardRef, useEffect, useRef } from 'react'

export interface ModalProps extends HTMLAttributes<HTMLDialogElement> {
  isOpen: boolean
  onClose: () => void
  title?: string
}

export const Modal = forwardRef<HTMLDialogElement, ModalProps>(
  ({ className = '', isOpen, onClose, title, children, ...props }, ref) => {
    const internalRef = useRef<HTMLDialogElement>(null)
    const dialogRef = (ref as React.RefObject<HTMLDialogElement>) || internalRef

    useEffect(() => {
      const dialog = dialogRef.current
      if (!dialog) return

      if (isOpen) {
        dialog.showModal()
      } else {
        dialog.close()
      }
    }, [isOpen, dialogRef])

    const handleBackdropClick = (e: React.MouseEvent<HTMLDialogElement>) => {
      if (e.target === e.currentTarget) {
        onClose()
      }
    }

    const handleClose = () => {
      onClose()
    }

    return (
      <dialog
        ref={dialogRef}
        className={`modal ${className}`.trim()}
        onClose={handleClose}
        onClick={handleBackdropClick}
        {...props}
      >
        <div className="modal-box">
          {title && <h3 className="font-bold text-lg">{title}</h3>}
          <button
            type="button"
            className="btn btn-sm btn-circle btn-ghost absolute right-2 top-2"
            onClick={onClose}
            aria-label="Close modal"
          >
            ×
          </button>
          <div className="py-4">{children}</div>
          <div className="modal-action">
            <form method="dialog">
              <button type="button" className="btn" onClick={onClose}>
                Close
              </button>
            </form>
          </div>
        </div>
      </dialog>
    )
  }
)

Modal.displayName = 'Modal'

import { InputHTMLAttributes, forwardRef, useId } from 'react'

export interface InputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> {
  label?: string
  error?: string
  type?: 'text' | 'email' | 'file' | 'password' | 'number' | 'tel' | 'url'
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ className = '', label, error, type = 'text', id, ...props }, ref) => {
    const generatedId = useId()
    const inputId = id || generatedId

    const errorClass = error ? 'input-error' : ''

    return (
      <div className="form-control w-full">
        {label && (
          <label className="label" htmlFor={inputId}>
            <span className="label-text">
              {label}
              {props.required && <span className="text-error ml-1">*</span>}
            </span>
          </label>
        )}
        <input
          ref={ref}
          id={inputId}
          type={type}
          className={`input input-bordered w-full ${errorClass} ${className}`.trim()}
          aria-invalid={error ? 'true' : undefined}
          aria-describedby={error ? `${inputId}-error` : undefined}
          {...props}
        />
        {error && (
          <label className="label" id={`${inputId}-error`}>
            <span className="label-text-alt text-error">{error}</span>
          </label>
        )}
      </div>
    )
  }
)

Input.displayName = 'Input'

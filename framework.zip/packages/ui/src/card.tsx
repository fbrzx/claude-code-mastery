import { HTMLAttributes, forwardRef } from 'react'

export interface CardProps extends HTMLAttributes<HTMLDivElement> {
  bordered?: boolean
  compact?: boolean
}

export const Card = forwardRef<HTMLDivElement, CardProps>(
  ({ className = '', bordered = false, compact = false, children, ...props }, ref) => {
    const borderedClass = bordered ? 'card-bordered' : ''
    const compactClass = compact ? 'card-compact' : ''

    return (
      <div
        ref={ref}
        className={`card bg-base-100 shadow-xl ${borderedClass} ${compactClass} ${className}`.trim()}
        {...props}
      >
        {children}
      </div>
    )
  }
)

Card.displayName = 'Card'

export interface CardBodyProps extends HTMLAttributes<HTMLDivElement> {}

export const CardBody = forwardRef<HTMLDivElement, CardBodyProps>(
  ({ className = '', children, ...props }, ref) => {
    return (
      <div ref={ref} className={`card-body ${className}`.trim()} {...props}>
        {children}
      </div>
    )
  }
)

CardBody.displayName = 'CardBody'

export interface CardTitleProps extends HTMLAttributes<HTMLHeadingElement> {}

export const CardTitle = forwardRef<HTMLHeadingElement, CardTitleProps>(
  ({ className = '', children, ...props }, ref) => {
    return (
      <h2 ref={ref} className={`card-title ${className}`.trim()} {...props}>
        {children}
      </h2>
    )
  }
)

CardTitle.displayName = 'CardTitle'

export interface CardActionsProps extends HTMLAttributes<HTMLDivElement> {
  justify?: 'start' | 'end' | 'center'
}

export const CardActions = forwardRef<HTMLDivElement, CardActionsProps>(
  ({ className = '', justify = 'end', children, ...props }, ref) => {
    const justifyClass = `justify-${justify}`

    return (
      <div ref={ref} className={`card-actions ${justifyClass} ${className}`.trim()} {...props}>
        {children}
      </div>
    )
  }
)

CardActions.displayName = 'CardActions'
